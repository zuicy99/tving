import React from "react";

const Intro = () => {
  return <div>Intro</div>;
};

export default Intro;
